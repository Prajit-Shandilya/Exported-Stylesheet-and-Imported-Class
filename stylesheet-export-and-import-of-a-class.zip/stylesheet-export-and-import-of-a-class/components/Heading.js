import * as React from 'react';
import { Text, View, Button, TouchableOpacity, StyleSheet } from 'react-native';
import { Audio } from 'expo-av';

class Heading extends React.Component {
  render() {
    return (
      <Text
        style={{
          backgroundColor: 'green',
          fontSize: '60px',
          fontWeight: 'bold',
          color: 'Red',
        }}>
        {' '}
        Sound App{' '}
      </Text>
    );
  }
}

export default Heading;
